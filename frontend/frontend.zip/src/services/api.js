import axios from "axios";

const API_BASE_URL = "http://localhost:8080/api";

// ✅ Axios instance with baseURL
const api = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true, // Ensure cookies are sent if needed
});

// ✅ Automatically attach JWT token from localStorage and handle refresh
api.interceptors.request.use(
  async (config) => {
    let token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response && error.response.status === 403 && !originalRequest._retry) {
      originalRequest._retry = true;
      const token = localStorage.getItem("token");
      try {
        const newToken = await refreshToken(token);
        if (newToken) {
          localStorage.setItem("token", newToken);
          api.defaults.headers.Authorization = `Bearer ${newToken}`;
          originalRequest.headers.Authorization = `Bearer ${newToken}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        console.error("Token refresh failed:", refreshError);
        localStorage.removeItem("token");
        window.location.href = "/login"; // Redirect to login on refresh failure
      }
    }
    console.error("API Error:", error.response ? error.response.data : error.message);
    return Promise.reject(error);
  }
);

// ✅ Register API
export const registerUser = async (userData) => {
  return api.post("/auth/register", userData).then((res) => res.data);
};

// ✅ Login API
export const loginUser = async (userData) => {
  const response = await api.post("/auth/login", userData);
  if (response.data.token) {
    localStorage.setItem("token", response.data.token);
  }
  return response.data.token;
};

// ✅ Refresh Token API
export const refreshToken = async (token) => {
  try {
    const response = await api.post("/refresh-token", {}, {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  } catch (error) {
    console.error("Refresh token error:", error);
    throw error;
  }
};

// ✅ Resume Creation API with proper error handling
export const createResume = async (resumeData) => {
  try {
    const response = await api.post("/resumes", resumeData);
    console.log("Resume creation response:", response.data);
    return response.data;
  } catch (error) {
    console.error("Resume creation error:", error.response ? error.response.data : error.message);
    throw error;
  }
};

export default api;