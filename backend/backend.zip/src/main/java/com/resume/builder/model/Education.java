package com.resume.builder.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "education")
@Data
public class Education {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String school;
    private String degree;
    private String fieldOfStudy;
    private String startYear;
    private Integer endYear;
    private String graduationYear;
    private String institution;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
        name = "resume_id", 
        nullable = false,
        foreignKey = @ForeignKey(
            name = "fkjyor7xegks1vh01tajsof6gb4",
            foreignKeyDefinition = "FOREIGN KEY (resume_id) REFERENCES resumes(id) ON DELETE CASCADE"
        )
    )
    private Resume resume;
}