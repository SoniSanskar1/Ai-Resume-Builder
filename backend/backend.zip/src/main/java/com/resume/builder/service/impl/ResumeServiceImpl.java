package com.resume.builder.service.impl;

import com.resume.builder.dto.ResumeRequest;
import com.resume.builder.model.*;
import com.resume.builder.repository.ResumeRepository;
import com.resume.builder.service.ResumeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ResumeServiceImpl implements ResumeService {
    private final ResumeRepository resumeRepository;

    @Override
    @Transactional
    public Resume createResume(ResumeRequest request, User user) {
        // 1. Create Resume entity (not saved yet)
        Resume resume = new Resume();
        resume.setFullName(request.getFullName());
        resume.setPhone(request.getPhone());
        resume.setTitle(request.getTitle());
        resume.setSummary(request.getSummary());
        resume.setUser(user);

        // 2. Set up bidirectional relationships BEFORE saving
        if (request.getEducationList() != null) {
            request.getEducationList().forEach(edu -> {
                Education education = new Education();
                education.setSchool(edu.getSchool());
                education.setDegree(edu.getDegree());
                education.setFieldOfStudy(edu.getFieldOfStudy());
                education.setStartYear(edu.getStartYear());
                education.setEndYear(edu.getEndYear());
                education.setGraduationYear(edu.getGraduationYear());
                education.setInstitution(edu.getInstitution());
                education.setResume(resume); // Critical bidirectional link
                resume.getEducationList().add(education);
            });
        }

        if (request.getExperienceList() != null) {
            request.getExperienceList().forEach(exp -> {
                Experience experience = new Experience();
                experience.setCompany(exp.getCompany());
                experience.setPosition(exp.getPosition());
                experience.setDuration(exp.getDuration());
                experience.setRole(exp.getRole());
                experience.setResume(resume); // Critical bidirectional link
                resume.getExperienceList().add(experience);
            });
        }

        if (request.getSkills() != null) {
            resume.setSkills(request.getSkills().stream()
                .filter(skill -> skill != null && !skill.trim().isEmpty())
                .map(String::trim)
                .collect(Collectors.toList()));
        }

        // 3. Single save operation with proper cascading
        return resumeRepository.save(resume);
    }
}