package com.resume.builder.model;

import jakarta.persistence.*;
import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "resumes")
@Data
public class Resume {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fullName;
    private String phone;
    private String title;
    private String summary;

    @OneToMany(
        mappedBy = "resume",
        cascade = CascadeType.ALL, // Includes PERSIST, MERGE, REMOVE, REFRESH, DETACH
        orphanRemoval = true,
        fetch = FetchType.LAZY
    )
    private List<Education> educationList = new ArrayList<>();

    @OneToMany(
        mappedBy = "resume",
        cascade = CascadeType.ALL,
        orphanRemoval = true,
        fetch = FetchType.LAZY
    )
    private List<Experience> experienceList = new ArrayList<>();

    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "skills",
        joinColumns = @JoinColumn(name = "resume_id"),
        foreignKey = @ForeignKey(name = "fk_skills_resume")
    )
    @Column(name = "skill_name")
    private List<String> skills = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    // Helper methods for bidirectional relationships
    public void addEducation(Education education) {
        educationList.add(education);
        education.setResume(this);
    }

    public void addExperience(Experience experience) {
        experienceList.add(experience);
        experience.setResume(this);
    }
}