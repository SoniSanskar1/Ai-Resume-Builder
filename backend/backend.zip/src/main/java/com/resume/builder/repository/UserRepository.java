package com.resume.builder.repository;

import com.resume.builder.model.User;
import com.resume.builder.model.Resume;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    // Find a User by email
    Optional<User> findByEmail(String email);
    
    // Check if a User exists with a specific email
    boolean existsByEmail(String email);
    
    // Find a User by username
    Optional<User> findByUsername(String username);

    // Additional method to fetch User with their resume, education, and experience if needed
    Optional<User> findByEmailWithResumeAndExperience(String email);

    // Additional method to check if a User has a resume (based on new structure)
    Optional<Resume> findResumeByUserId(Long userId);
}
